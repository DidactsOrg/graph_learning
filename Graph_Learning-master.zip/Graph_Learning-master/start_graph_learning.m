clear all
clc
close all

addpath('functions');
addpath('misc');

disp('GLL Package v.2.1');